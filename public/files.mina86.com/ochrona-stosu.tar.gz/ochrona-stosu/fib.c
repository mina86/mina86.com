#include <stdio.h>
#include <stdlib.h>

static unsigned long long count = 0;

unsigned long long fib(unsigned n) {
	++count;
	return n > 1 ? fib(n - 2) + fib(n - 1) : n;
}

int main(int argc, char **argv) {
	unsigned long long f = fib(argc > 1 ? strtoul(argv[1], 0, 0) : 10);
	printf("%llu (%llu calls)\n", f, count);
	return 0;
}
