#include <stdio.h>
#include <string.h>

static int validate(char *pass) {
    char buf[10];
    int valid = 0;
    strcpy(buf, pass);
    if (!strcmp(buf, "password")) {
        valid = 1;
    }
    return valid;
}

int main(int argc, char **argv) {
    if (argc != 2 || !validate(argv[1])) {
        puts("Sorry.");
        return 1;
    }
    puts("Welcome!");
    return 0;
}
