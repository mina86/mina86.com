#include <stdio.h>
#include <string.h>

static int validate(char *pass) {
    char buf[10];
    strcpy(buf, pass);
    return !strcmp(buf, "password");
}

int main(int argc, char **argv) {
    if (argc != 2 || !validate(argv[1])) {
        puts("Sorry.");
        return 1;
    }
    puts("Welcome!");
    return 0;
}
