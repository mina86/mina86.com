#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void do_job(int valid, char *pass) {
    char buf[10];
    strcpy(buf, pass);
    if (!valid && !strcmp(buf, "password")) {
        valid = 1;
    }

    if (valid) {
        puts("Welcome!");
        exit(0);
    } else {
        puts("Sorry.");
        exit(1);
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        puts("Sorry.");
        return 1;
    } else {
        do_job(0, argv[1]);
    }
}
